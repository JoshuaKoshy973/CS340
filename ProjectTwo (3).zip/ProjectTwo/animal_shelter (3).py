#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Jul 28 17:42:14 2025

@author: joshuakoshy_snhu
"""

from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, username, password):
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 30318
        DB = 'AAC'
        COL = 'animals'
    
        self.client = MongoClient(f'mongodb://{username}:{password}@{HOST}:{PORT}')
        self.database = self.client[DB]
        self.collection = self.database[COL]

    # Create method (insert a document)
    def create(self, data):
        if data is not None:
            insert_result = self.collection.insert_one(data)
            return True if insert_result.acknowledged else False
        else:
            raise Exception("Nothing to save, data is empty")

    # Read method (find documents)
    def read(self, query):
        if query is not None:
            results = list(self.collection.find(query))
            return results
        else:
            raise Exception("Query is empty")
      
    
    def update(self, query, new_values):
        if query and new_values:
            update_result = self.collection.update_many(query, {"$set": new_values})
            return update_result.modified_count
        else:
            raise Exception("Query or new values are missing")


    def delete(self, query):
        if query:
            delete_result = self.collection.delete_many(query)
            return delete_result.deleted_count
        else:
            raise Exception("Query is missing")

            